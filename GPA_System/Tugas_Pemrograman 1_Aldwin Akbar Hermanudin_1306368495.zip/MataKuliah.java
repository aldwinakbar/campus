
/**
 * Write a description of class MataKuliah here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MataKuliah
{
    // instance variables - replace the example below with your own
    private String namaMK;
    private int sks;
    private int semester;
    private String nilai;

    /**
     * Constructor for objects of class MataKuliah
     */
    public MataKuliah(String namaMataKuliah, int sksMK, int semesterMK)
    {
        namaMK =  namaMataKuliah;
        sks = sksMK;
        semester =semesterMK;
    }

    public String getNamaMK()
    {
        return namaMK;
    }
    
    public void setNamaMK(String namaMK)
    {
        this.namaMK = namaMK;
    }
    
    public int getSKS()
    {
        return sks;
    }
        
    public void setSKS(int sks)
    {
        if( sks > 0 && sks < 9){
            this.sks = sks;
        }
    }    
    
    public int getSemester()
    {
        return semester;
    }
    
    public void setSemester(int semester)
    {
        if( semester > 0 && semester < 13){
            this.semester = semester;
        }
    }
    
    public String getNilai()
    {
        return nilai;
    }
    
    public void setNilai(String nilai) 
    {
         if (nilai.equals("A") || nilai.equals("A-") || nilai.equals("B+") || nilai.equals("B") || nilai.equals("B-") || nilai.equals("C+") || nilai.equals("C") || nilai.equals("D") || nilai.equals("E")){
           this.nilai = nilai; 
            
         }
    }
    
    public double hitungBobot()
    {
        double hasil;
        if (nilai.equals("A")){
            hasil = 4*sks;
        }
        else if (nilai.equals("A-")){
            hasil = 3.7*sks;
        }
        else if (nilai.equals("B+")){
            hasil = 3.3*sks;
        }
        else if (nilai.equals("B")){
            hasil = 3*sks;
        }
        else if (nilai.equals("B-")){
            hasil = 2.7*sks;
        }
        else if (nilai.equals("C+")){
            hasil = 2.3*sks;
        }
        else if (nilai.equals("C")){
            hasil = 2*sks;
        }
        else if (nilai.equals("D")){
            hasil = 1*sks;
        }
        else {
            hasil = 0;
        }
        
        return hasil;        
    }
    
}
